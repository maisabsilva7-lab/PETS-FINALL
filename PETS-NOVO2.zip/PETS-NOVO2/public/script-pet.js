const petForm = document.getElementById('petForm');

//verifica se o botão enviar foi clicado
petForm.addEventListener('submit', async (e) => {
    e.preventDefault();


//o formData empacota os dados que foram digitados na tela 
const formData = new FormData();
formData.append('tutor', document.getElementById('tutor').value.trim());
formData.append('nome_pet', document.getElementById('nome_pet').value.trim());
formData.append('raca', document.getElementById('raca').value.trim());
formData.append('genero', document.getElementById('genero').value.trim());
formData.append('peso', document.getElementById('peso').value.trim());
formData.append('idade', document.getElementById('idade').value.trim());


//cria uma variavel para guardar a identificação da imagem 
const imagemInput = document.getElementById('imagem');
//verifica se exite imagem 
if(imagemInput.files[0]){
    //inclui a imagem dentro do pacote formData 
    formData.append('imagem', imagemInput.files[0]);
}
//verifica se tem erros no servidor e envia os dados para o back-end
try {
    const Response = await fetch('http://localhost:3000/api/pets', {
        method: 'POST',
        body: formData,
    });
    
    const  data = await Response.json();

//verifica se os campos foram enviados com sucesso 
if(Response.ok){
    alert(data.message);
    petForm.reset();
    //window.location.href = '';

}else{
    alert(data.message);
}
} catch(erro){
    console.error('erro na requisição', error);
    alert('erro ao conectar com o servidor.');
}
});